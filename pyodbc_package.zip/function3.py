import ceODBC


conn = ceODBC.connect("DSN=api-production")

cursor = conn.cursor()
cursor.execute("""
        select name from xactly.xc_period limit 10;""")

for column_1 in cursor:
    print("Values:", column_1)

print(conn)
print(ceODBC.drivers())

