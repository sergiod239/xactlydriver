"""
Contains the current version of the module (used by setup.cfg as well as
imported by the package initialization module).
"""

__version__ = "3.1"
